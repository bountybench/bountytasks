:orphan:

.. _dynamic_work:

#####################
Dynamic LightningWork
#####################

**Audience:** Users who want to create applications that adapt to user demands.

**Level:** Advanced

----

.. include:: dynamic_work_content.rst
