:orphan:

.. _core_api:

###############################
Learn more about Lightning Core
###############################

.. raw:: html

   <div class="display-card-container">
      <div class="row">

.. displayitem::
   :header: Level-up with Lightning Apps
   :description: From Basics to Advanced Skills
   :col_css: col-md-6
   :button_link: ../levels/basic/index.html
   :height: 180

.. displayitem::
   :header: Understand Lightning App
   :description: Detailed description
   :col_css: col-md-6
   :button_link: lightning_app/index.html
   :height: 180

.. displayitem::
   :header: Understand Lightning Flow
   :description: Detailed description
   :col_css: col-md-6
   :button_link: lightning_flow.html
   :height: 180

.. displayitem::
   :header: Understand Lightning Work
   :description: Detailed description
   :col_css: col-md-6
   :button_link: lightning_work/index.html
   :height: 180
