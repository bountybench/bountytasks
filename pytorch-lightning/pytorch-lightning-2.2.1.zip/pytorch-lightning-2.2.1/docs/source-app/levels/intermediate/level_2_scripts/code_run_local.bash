lightning run app app.py
