###########################
Level 16: Check Work status
###########################
**Audience:** Users who want to stop/start Lightning Work based on a status.

**Prereqs:** Level 16+

----

.. include:: ../../core_api/lightning_work/status_content.rst
