#########################################
Level 19: Handle Lightning App exceptions
#########################################

**Audience:** Users who want to make Lightning Apps more robust to potential issues.

**Prereqs:** Level 16+

----

.. include:: ../../core_api/lightning_work/handling_app_exception_content.rst
