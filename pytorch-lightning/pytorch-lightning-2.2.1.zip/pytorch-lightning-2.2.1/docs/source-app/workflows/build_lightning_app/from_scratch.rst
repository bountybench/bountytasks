####################################
Develop a Lightning App from Scratch
####################################

**Audience:** Users who want to develop a Lightning App from scratch.

**Prereqs:** You must have finished the `Basic levels <https://lightning.ai/lightning-docs/levels/basic/>`_.

----

.. include:: from_scratch_content.rst
