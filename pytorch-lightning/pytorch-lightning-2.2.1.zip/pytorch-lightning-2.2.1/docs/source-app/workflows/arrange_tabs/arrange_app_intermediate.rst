###############################
Arrange app tabs (intermediate)
###############################

.. TODO:: fill-in

----

***********************************
Render components with a defined UI
***********************************

component directly

----

*************
Render a link
*************

tensorboard link
