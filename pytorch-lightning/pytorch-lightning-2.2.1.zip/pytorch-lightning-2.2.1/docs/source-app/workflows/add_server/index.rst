###################################
Run a server within a Lightning App
###################################
Any type of server can run inside a Lightning App.

----

.. include:: index_content.rst
