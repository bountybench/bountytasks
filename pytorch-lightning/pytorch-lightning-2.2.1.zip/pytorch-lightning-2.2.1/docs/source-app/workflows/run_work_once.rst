##########################
Cache LightningWork Runs
##########################

**Audience:** Users who want to know how ``LightningWork`` works.

**Level:** Advanced

**Prereqs**: Level 16+ and read the :doc:`Event Loop guide <../glossary/event_loop>`.

----

.. include:: run_work_once_content.rst
