#####################################
Add a web UI with HTML (intermediate)
#####################################
**Audience:** Users who want to add a web UI using plain html.

**Prereqs:** Must have read the :doc:`html basic <basic>` guide.

----

*******************************
Interact with the App from HTML
*******************************
.. note:: documentation in progress

----

***********************************
Interact with HTML from a component
***********************************
.. note:: documentation in progress
