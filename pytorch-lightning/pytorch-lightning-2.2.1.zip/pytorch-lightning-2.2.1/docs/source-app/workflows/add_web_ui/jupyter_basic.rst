:orphan:

#####################################
Add a Jupyter Notebook web UI (basic)
#####################################
**Audience:** Users who want to enable a Jupyter notebook UI.

**Prereqs:** Basic python knowledge.

TODO

----

***************************
What is a Jupyter Notebook?
***************************

TODO

----

*******************
Install Jupyter Lab
*******************

First, install Jupyter Lab.

.. code:: bash

    pip install jupyterlab

----

********
Examples
********
Here are a few example apps that use Jupyter Lab.

.. raw:: html

    <div class="display-card-container">
        <div class="row">

.. Add callout items below this line

.. displayitem::
   :header: Example 1
   :description: TODO
   :col_css: col-md-4
   :button_link: angular_js_intermediate.html
   :height: 150

.. displayitem::
   :header: Example 2
   :description: TODO
   :col_css: col-md-4
   :button_link: angular_js_intermediate.html
   :height: 150

.. displayitem::
   :header: Example 3
   :description: TODO
   :col_css: col-md-4
   :button_link: angular_js_intermediate.html
   :height: 150

.. raw:: html

        </div>
    </div>
