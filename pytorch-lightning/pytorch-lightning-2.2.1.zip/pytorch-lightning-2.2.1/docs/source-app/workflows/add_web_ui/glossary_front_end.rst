########
Frontend
########
Web pages visible to users are also known as **front-ends**. Lightning Apps can have multiple
types of Frontends.

----

.. include:: index_content.rst
