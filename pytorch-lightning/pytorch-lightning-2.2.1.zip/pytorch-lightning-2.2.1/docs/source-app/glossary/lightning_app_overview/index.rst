:orphan:

###########################
Lightning Apps Key concepts
###########################

**Audience:** Users who want to know how the 🤯 magic works under the hood.

----

.. note:: This page is under construction
