.. include:: ../workflows/mount_cloud_object_store.rst
