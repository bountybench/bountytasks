# install lightning
pip install lightning

# run the app on the --cloud (--setup installs deps automatically)
lightning_app run app app.py --setup --cloud
