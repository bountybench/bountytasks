:orphan:

################
Template Trainer
################

.. TODO:: Write a guide explaining how to build a template like the one in https://github.com/Lightning-AI/lightning/tree/master/examples/fabric/build_your_own_trainer
